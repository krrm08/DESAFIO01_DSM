package com.example.calculadora_dsafio01_dsm

import android.annotation.SuppressLint
import android.media.VolumeShaper.Operation
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    //Declaracion de variables del usuario
    private lateinit var input1: EditText
    private lateinit var input2: EditText
    private lateinit var buttonAdd: Button
    private lateinit var buttonSubtract: Button
    private lateinit var buttonMultiply: Button
    private lateinit var buttonDivide: Button
    private lateinit var textViewResult: TextView


    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main) //Este es el archivo del diseño para la app

        //Inicializamos los elementos de la interfaz
        input1 = findViewById(R.id.input1)
        input2 = findViewById(R.id.input2)
        buttonAdd = findViewById(R.id.buttonAdd)
        buttonSubtract = findViewById(R.id.buttonSubtract)
        buttonMultiply = findViewById(R.id.buttonMultiply)
        buttonDivide = findViewById(R.id.buttonDivide)
        textViewResult = findViewById(R.id.textViewResult)


        //Configuracion de los metodos "calculate" con cada operacion
        buttonAdd.setOnClickListener {calculate (Operation.ADD) }
        buttonSubtract.setOnClickListener {calculate (Operation.SUBTRACT) }
        buttonMultiply.setOnClickListener {calculate (Operation.MULTIPLY) }
        buttonDivide.setOnClickListener {calculate (Operation.DIVIDE) }
    }

    //Metodo CALCULATE
    private fun calculate(operation: Operation) {
        //Obtiene los valores de entrada como cadena
        val input1Text = input1.text.toString()
        val input2Text = input2.text.toString()

        //Verifica si cambos campos estan llenos
        if (input1Text.isEmpty() || input2Text.isEmpty()) {
            Toast.makeText(this, "Por favor, ingresa ambos números",
                Toast.LENGTH_SHORT).show()
            return
        }

        //Conversion de entradas de texto a numeros
        val num1 = input1Text.toDouble()
        val num2 = input2Text.toDouble()
        var result = 0.0 //Variable para almacenar el resultado

        //Diferentes operaciones a realizar
        when (operation){
            Operation.ADD -> result = num1 + num2
            Operation.SUBTRACT -> result = num1 - num2
            Operation.MULTIPLY -> result = num1 * num2
            Operation.DIVIDE -> {
                //Manejo en caso de querer dividir entre 0
                if (num2 == 0.0) {
                    Toast.makeText(this, "No se puede dividir entre 0", Toast.LENGTH_SHORT).show()
                    return
                }
                result = num1 / num2
            }
        }

        //Actualiza el textView para mostrar el resultado
        textViewResult.text = getString(R.string.result) + result.toString()
    }

    //enumeracion para representar las operaciones
    enum class Operation{
        ADD, SUBTRACT, MULTIPLY, DIVIDE
    }
}