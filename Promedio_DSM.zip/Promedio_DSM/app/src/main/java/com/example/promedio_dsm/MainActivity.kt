package com.example.promedio_dsm

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    // Declaracion de variables del usuario
    private lateinit var input1: EditText
    private lateinit var input2: EditText
    private lateinit var input3: EditText
    private lateinit var input4: EditText
    private lateinit var input5: EditText
    private lateinit var btnCalc: Button
    private lateinit var txtViewResult: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main) // Archivo layout que mostrará al usuario

        // Inicializamos los elementos de la interfaz
        input1 = findViewById(R.id.input1)
        input2 = findViewById(R.id.input2)
        input3 = findViewById(R.id.input3)
        input4 = findViewById(R.id.input4)
        input5 = findViewById(R.id.input5)
        btnCalc = findViewById(R.id.buttonCalc)
        txtViewResult = findViewById(R.id.txtViewResult)

        btnCalc.setOnClickListener {
            // Obtener los valores de los EditText y convertirlos a Double
            val note1 = input1.text.toString().toDoubleOrNull()
            val note2 = input2.text.toString().toDoubleOrNull()
            val note3 = input3.text.toString().toDoubleOrNull()
            val note4 = input4.text.toString().toDoubleOrNull()
            val note5 = input5.text.toString().toDoubleOrNull()

            // Validar que las notas estén en el rango de 0 a 10
            if (note1 == null || note1 !in 0.0..10.0 ||
                note2 == null || note2 !in 0.0..10.0 ||
                note3 == null || note3 !in 0.0..10.0 ||
                note4 == null || note4 !in 0.0..10.0 ||
                note5 == null || note5 !in 0.0..10.0) {

                // Mostrar mensaje de error si alguna nota está fuera del rango
                Toast.makeText(this, "Por favor, ingrese notas válidas entre 0 y 10.", Toast.LENGTH_SHORT).show()
            } else {

                // Calcular el promedio
                val prom = ((note1 * 0.15) + (note2 * 0.15) + (note3 * 0.20) + (note4 * 0.25) + (note5 * 0.25))

                // Actualizar el txtView para mostrar el resultado
                txtViewResult.text = getString(R.string.prom) + prom.toString()
            }
        }
    }
}
